from datetime import datetime

from flask import Flask, render_template, request,redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///event.db"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class events(db.Model):
    sno = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    disc = db.Column(db.String(500), nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self) -> str:
        return f"{self.sno} - {self.title}"

@app.route("/" , methods=['GET', 'POST'])
def index():

    if request.method == 'POST':
        title= request.form['title']
        disc = request.form['disc']

        event=events(title=title,disc=disc)
        db.session.add(event)
        db.session.commit()

    allevent = events.query.all() 

    return render_template('index.html' ,all = allevent)

@app.route('/update/<int:sno>', methods=['GET', 'POST'])
def update(sno):

        event = events.query.filter_by(sno=sno).first()
        db.session.delete(event)
        db.session.commit()
        return render_template("index.html",update=True ,title=event.title,disc=event.disc)


@app.route("/delete/<int:sno>")
def delete(sno):
    event = events.query.filter_by(sno=sno).first()
    db.session.delete(event)
    db.session.commit()
    return redirect("/")


if __name__=='__main__':
    app.run(debug=True)

